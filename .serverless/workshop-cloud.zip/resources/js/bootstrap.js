import _ from 'lodash';
import axios from 'axios';
import Pusher from "pusher-js";
import Echo from "laravel-echo";

function bootstrap() {

}

export { bootstrap };
